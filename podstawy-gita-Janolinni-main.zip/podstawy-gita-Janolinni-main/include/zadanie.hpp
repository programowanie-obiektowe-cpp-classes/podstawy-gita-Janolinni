// Zadanie: zmodyfikuj funkcję tak, aby zwracała sumę argumentów
int dodaj(int a, int b) { return 0; }
